#include <iostream>
#include "lista_ordenada.h"

using namespace std;

OrderedList::OrderedList(){
    sentinel = new ListNode;
    head = sentinel;
    count = 0;
}

OrderedList::~OrderedList(){
    clear();
    delete sentinel;
}

bool OrderedList::empty(){
    return (head == sentinel);
}

bool OrderedList::full(){
    return false;
}

void OrderedList::insert(ListEntry x){ 
    ListPointer p, q;
    sentinel->entry = x;
    p = head;
    while(p->entry.expoente > x.expoente)
        p = p->nextNode;

    q = new ListNode;
    if(q == NULL){ 
        cout << "Memória insuficiente";
        abort();
    }

    if(p == sentinel){
        p->nextNode = q;
        sentinel = q;
    }
    else{ 
        *q = *p;
        p->entry = x;
        p->nextNode = q;
    }
    count++;
}

void OrderedList::clear()
{ 
    ListPointer q;

    while (head != sentinel){ 
        q = head;
        head = head->nextNode;
        delete q;
    }
    count = 0;
}