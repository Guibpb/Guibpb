#include <iostream>
#include "lista_ordenada.h"

int main(){

    return 0;
}